#!/usr/bin/env bash

#######################
# MAIN script body
#######################
. /hive/custom/$CUSTOM_MINER/h-manifest.conf
local LOG_NAME="$CUSTOM_LOG_BASENAME.log"

khs=0	

stats_raw=`cat /var/log/miner/bisminer/bisminer.stat | sed 's/\"\[/\[/' | sed 's/\]\"/\]/'`
echo $stats_raw | jq .
if [[ -z $stats_raw ]]; then
	echo -e "${YELLOW}Failed to read $miner stats${NOCOLOR}"
else
	khs=`echo $stats_raw | jq -r '.khs' | awk '{print $1*1000}'`
	local temp=$(jq '.temp' <<< $gpu_stats)
	local fan=$(jq '.fan' <<< $gpu_stats)
	local hs=`echo $stats_raw | jq -r '.stats.hs'`
	stats=$(jq --argjson temp "$temp" --argjson fan "$fan" --arg ac "$ac" --arg rj "$rj" \
		'{hs: .stats.hs , $temp, $fan, uptime: .stats.uptime, ar: .stats.ar}' <<< "$stats_raw")
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
